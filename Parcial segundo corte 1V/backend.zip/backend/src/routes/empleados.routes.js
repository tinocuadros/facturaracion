// Importamos Router de Express y el controlador de empleados
import { Router } from "express";
import { methodHTTP as empleadoController } from "../controllers/empleados.controllers.js";

// Almacenamos todo el poder de Router en router
const router1 = Router();

// GET y POST 
router1.get("/", empleadoController.getEmpleados); // para el CRUD - 
router.post("/", empleadoController.postEmpleado); // CREATE 

// Ruta que recibe un parámetro id
router1.get("/:id", empleadoController.getEmpleado); 
router1.delete("/:id", empleadoController.deleteEmpleado); // DELETE 
router1.put("/:id", empleadoController.updateEmpleado); // UPDATE 

// Exportamos 
export default router1;